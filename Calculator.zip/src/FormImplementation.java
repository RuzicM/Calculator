public class FormImplementation implements FormListener {


    @Override
    public int addition(int firstNumber, int secondNumber) {
        return firstNumber+secondNumber;
    }


    @Override
    public int subtraction(int firstNumber, int secondNumber) {
        return firstNumber-secondNumber;
    }

    @Override
    public int multiplication(int firstNumber, int secondNumber) {
        return firstNumber*secondNumber;
    }

    @Override
    public double division(int firstNumber, int secondNumber) {
        return firstNumber/secondNumber;
    }
}