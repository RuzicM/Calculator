import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FormPanel extends JPanel {
    private FormImplementation formImplementation;
    private TextPanel textPanel;
    private ButtonGroup operationGroup;
    private JRadioButton additionButton;
    private JRadioButton subtractionButton;
    private JRadioButton multiplicationButton;
    private JRadioButton divisionButton;
    private FormListener formListener;
    private JLabel firstLabel;
    private JTextField firstField;
    private JLabel secondLabel;
    private JTextField secondField;
    private JLabel resultLabel;
    private JTextField resultField;
    private JButton submit;

    private EventHandler eventHandler;

    public FormPanel(EventHandler eventHandler) {
        setLayout(new BorderLayout());

        Dimension dimension = getPreferredSize();
        dimension.width = 250;
        setPreferredSize(dimension);

        Border innerBorder = BorderFactory.createTitledBorder("Calculator");
        Border outerBorder = BorderFactory.createEmptyBorder(5, 5, 5, 5);
        setBorder(BorderFactory.createCompoundBorder(innerBorder, outerBorder));

        this.eventHandler = eventHandler;
        textPanel = new TextPanel();
        additionButton = new JRadioButton("Addition");
        subtractionButton = new JRadioButton("subtraction");
        multiplicationButton = new JRadioButton("Multiplication");
        divisionButton = new JRadioButton("Division");
        operationGroup = new ButtonGroup();

        operationGroup.add(additionButton);
        operationGroup.add(subtractionButton);
        operationGroup.add(multiplicationButton);
        operationGroup.add(divisionButton);
        additionButton.setSelected(true);

        additionButton.setActionCommand("Addition");
        subtractionButton.setActionCommand("Subtraction");
        multiplicationButton.setActionCommand("Multiplication");
        divisionButton.setActionCommand("Division");


        firstLabel = new JLabel("First ");
        firstField = new JTextField(5);
        secondLabel = new JLabel("Second ");
        secondField = new JTextField(5);
        resultLabel = new JLabel("Result");
        resultField = new JTextField(5);
        submit = new JButton("Submit");
        System.out.println(operationGroup.getSelection());

        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String firstNumber = firstField.getText();
                String secondNumber = secondField.getText();
                String selected = operationGroup.getSelection().getActionCommand();
                int firstNum = Integer.parseInt(firstNumber);
                int secondNum = Integer.parseInt(secondNumber);

                EventClass eventClass = new EventClass(this, firstNum, secondNum, selected);

                eventHandler.handle(eventClass);

                }

        });
        setLayout(new GridBagLayout());
        display();
    }

    public void display() {
        GridBagConstraints grid = new GridBagConstraints();
        Insets labelInsets = new Insets(0, 0, 0, 5);
        Insets fieldInsets = new Insets(0, 0, 0, 0);


        /////////////////////NEW ROW////////////////////////
        grid.gridy = 0;
        grid.weightx = 1;
        grid.weighty = 0.1;

        grid.gridx = 0;
        grid.anchor = GridBagConstraints.LINE_END;
        grid.insets = fieldInsets;
        add(additionButton, grid);

        grid.gridx = 1;
        grid.anchor = GridBagConstraints.LINE_START;
        grid.insets = fieldInsets;
        add(subtractionButton, grid);
        /////////////////////NEW ROW////////////////////////
        grid.gridy++;
        grid.weightx = 1;
        grid.weighty = 0.1;

        grid.gridx = 0;
        grid.anchor = GridBagConstraints.LINE_END;
        grid.insets = fieldInsets;
        add(multiplicationButton, grid);

        grid.gridx = 1;
        grid.anchor = GridBagConstraints.LINE_START;
        grid.insets = fieldInsets;
        add(divisionButton, grid);
        /////////////////////NEW ROW////////////////////////
        grid.gridy++;
        grid.weightx = 1;
        grid.weighty = 0.1;

        grid.gridx = 0;
        grid.fill = GridBagConstraints.NONE;
        grid.anchor = GridBagConstraints.LINE_END;
        grid.insets = labelInsets;
        add(firstLabel, grid);

        grid.gridx = 1;
        grid.anchor = GridBagConstraints.LINE_START;
        grid.insets = labelInsets;
        add(firstField, grid);
/////////////////////NEW ROW////////////////////////
        grid.gridy++;
        grid.weightx = 1;
        grid.weighty = 0.1;

        grid.gridx = 0;
        grid.anchor = GridBagConstraints.FIRST_LINE_END;
        grid.insets = fieldInsets;
        add(secondLabel, grid);

        grid.gridx = 1;
        grid.anchor = GridBagConstraints.FIRST_LINE_START;
        grid.insets = fieldInsets;
        add(secondField, grid);
        /////////////////////NEW ROW////////////////////////
        grid.gridy++;
        grid.weightx = 1;
        grid.weighty = 2.0;

        grid.gridx = 1;
        grid.anchor = GridBagConstraints.FIRST_LINE_START;
        grid.insets = fieldInsets;
        add(submit, grid);
    }

    public void setFormListener(FormListener formListener) {
        this.formListener = formListener;
    }


}
