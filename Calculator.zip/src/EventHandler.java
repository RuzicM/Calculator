public interface EventHandler {
    void handle(EventClass event);
}
