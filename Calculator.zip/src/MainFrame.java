import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

public class MainFrame extends JFrame {
    private TextPanel textPanel;
    private FormPanel formPanel;
    private EventHandler eventHandler;


    public MainFrame() {
        super("Calculator");
        setLayout(new BorderLayout());

        setJMenuBar(createMenu());

        textPanel = new TextPanel();
        eventHandler = new EventHandlerImpl(textPanel);
        formPanel = new FormPanel(eventHandler);


        add(textPanel, BorderLayout.CENTER);
        add(formPanel, BorderLayout.WEST);


        setVisible(true);
        setMinimumSize(new Dimension(500,300));
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public JMenuBar createMenu() {
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenu windowMenu = new JMenu("Window");

        JMenuItem exitMenu = new JMenuItem("Exit");
        menuBar.add(fileMenu);
        menuBar.add(windowMenu);
        fileMenu.add(exitMenu);

        fileMenu.setMnemonic(KeyEvent.VK_F);
        exitMenu.setMnemonic(KeyEvent.VK_X);
        exitMenu.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_MASK));
        exitMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                int result = JOptionPane.showConfirmDialog(MainFrame.this, "Do you want to exit", "Confirm for exit", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    System.exit(0);
                }
            }
        });

        JMenu showMenu = new JMenu("Show");
        JCheckBoxMenuItem formMenu = new JCheckBoxMenuItem("Hide calculator");
        windowMenu.add(showMenu);
        showMenu.add(formMenu);


        formMenu.setSelected(true);
        formMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JCheckBoxMenuItem selectedMenu = (JCheckBoxMenuItem) actionEvent.getSource();
                formPanel.setVisible(selectedMenu.isSelected());
            }
        });
        return menuBar;
    }
}
