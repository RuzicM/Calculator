public interface FormListener  {
    public int addition(int firstNumber, int secondNumber);

    public  int  subtraction(int firstNumber, int secondNumber);

    public  int  multiplication(int firstNumber, int secondNumber);

    public double division(int firstNumber, int secondNumber);


}
