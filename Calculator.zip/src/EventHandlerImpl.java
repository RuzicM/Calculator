public class EventHandlerImpl implements EventHandler {
    private TextPanel textPanel;
    private FormImplementation formImplementation = new FormImplementation();

    public EventHandlerImpl(TextPanel textPanel) {
        this.textPanel = textPanel;
    }

    @Override
    public void handle(EventClass event) {
        int result = 0;
        textPanel.textEmitted("");
        if (event.selectedOperation.equals("Addition")) {
            result = formImplementation.addition(event.getFirstNumber(), event.getSecondNumber());
        } else if (event.selectedOperation.equals("Subtraction")) {
            result = formImplementation.subtraction(event.getFirstNumber(), event.getSecondNumber());
        } else if (event.selectedOperation.equals("Multiplication")) {
            result = formImplementation.multiplication(event.getFirstNumber(), event.getSecondNumber());
        } else if (event.selectedOperation.equals("Division")) {
            result  = (int) formImplementation.division(event.getFirstNumber(), event.getSecondNumber());
        }

        textPanel.textEmitted(result + "");
    }
}
