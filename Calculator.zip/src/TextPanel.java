import javax.swing.*;
import java.awt.*;

public class TextPanel extends JPanel {
    private JTextArea jTextArea;

    public TextPanel() {
        setLayout(new BorderLayout());
        jTextArea = new JTextArea();

        add(new JScrollPane(jTextArea), BorderLayout.CENTER);

    }

    public void textEmitted(String string) {
        jTextArea.setText(string);
    }
}
