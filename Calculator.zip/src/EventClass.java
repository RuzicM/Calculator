import java.util.EventObject;

public class EventClass extends EventObject {
    private int firstNumber;
    private int secondNumber;
    String selectedOperation;

    public EventClass(Object o, int firstNumber, int secondNumber, String selectedOperation) {
        super(o);
        this.firstNumber = firstNumber;
        this.secondNumber = secondNumber;
        this.selectedOperation = selectedOperation;
    }

    public int getSecondNumber() {
        return secondNumber;

    }

    public int getFirstNumber() {
        return firstNumber;
    }

    public String getSelectedOperation() {
        return selectedOperation;
    }
}
